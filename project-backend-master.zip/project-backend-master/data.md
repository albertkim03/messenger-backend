```javascript
let data = {
    
    // TODO: insert your data structure that contains 
    // users + channels here

    // User object:
    users: [
        {
            userId: 1,
            nameFirst: 'Rani',
            nameLast: 'Jiang',
            email: 'ranivorous@gmail.com',
            password: 'abc123',
            handleStr: 'ranivorous',
            isAdmin: false
        }
    ],
    

    // Channel object:
    channels: [
        {
            name: typeof(string)
            isPublic: typeof(boolean),
            channelId: typeof(number),
            ownerMembers: user[]
            allMembers: user[]
            messages: [{
                messageId: 342, 
                uId: 234, 
                message: string
                timeSent: number (seconds)

            }],
        }
    ],

}
```

[Optional] short description: 
